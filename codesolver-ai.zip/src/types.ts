/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  fullName: string;
  userType: 'school' | 'college' | '';
  classYear: string; // e.g. "College: 1st Year", "School: Grade 10"
  studyField: string; // e.g. "Web Developer", "BCA", "Engineering", etc.
  email?: string;
}

export type AppTab =
  | 'home'
  | 'convert'
  | 'debug'
  | 'ask'
  | 'scan'
  | 'book'
  | 'ai'
  | 'learn'
  | 'profile'
  | 'login'
  | 'signup';

export interface AppState {
  isPremium: boolean;
  isAdFree: boolean;
  solvesRemaining: number;
  adProgress: number; // 0 to 3, matching watched count to earn 1 solve
  isLoggedIn: boolean;
}

export interface Exercise {
  id: string;
  title: string;
  description: string;
  startingCode: string;
  testPrompt: string; // instructions of what to try
}

export interface Lesson {
  id: string;
  title: string;
  category: 'python' | 'java' | 'cpp' | 'web' | 'javascript' | 'rust' | 'go' | 'kotlin' | 'swift' | 'sql' | 'bash';
  concept: string;
  text: string;
  codeSnippet: string;
  exercise: Exercise;
}
