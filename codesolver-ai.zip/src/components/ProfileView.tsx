/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, Award, CheckCircle, Gift, Sparkles, LogOut, ArrowRight, Video, AlertCircle, RotateCcw } from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileViewProps {
  profile: UserProfile;
  setProfile: (profile: UserProfile) => void;
  isPremium: boolean;
  onRedeemCode: (code: string) => boolean;
  solvesRemaining: number;
  adProgress: number;
  onWatchAd: () => void;
  onLogout: () => void;
  onUpgradeToPremium: () => void;
  onResetCreditsAndScores?: () => void;
}

export default function ProfileView({
  profile,
  setProfile,
  isPremium,
  onRedeemCode,
  solvesRemaining,
  adProgress,
  onWatchAd,
  onLogout,
  onUpgradeToPremium,
  onResetCreditsAndScores,
}: ProfileViewProps) {
  const [editingName, setEditingName] = useState(profile.fullName);
  const [editingType, setEditingType] = useState<'school' | 'college'>(profile.userType || 'college');
  const [editingClass, setEditingClass] = useState(profile.classYear || '1st Year');
  const [editingField, setEditingField] = useState(profile.studyField || 'Web Developer');
  const [redeemCode, setRedeemCode] = useState('');
  const [redeemMessage, setRedeemMessage] = useState<string | null>(null);
  const [redeemSuccess, setRedeemSuccess] = useState(false);
  const [isAdWatching, setIsAdWatching] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setProfile({
      fullName: editingName,
      userType: editingType,
      classYear: editingClass,
      studyField: editingField,
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleApplyRedeem = () => {
    const code = redeemCode.trim();
    if (!code) return;
    const success = onRedeemCode(code);
    if (success) {
      setRedeemSuccess(true);
      setRedeemMessage('👑 CODE ACCEPTED! Premium Membership and Ad-Free Mode Activated successfully!');
    } else {
      setRedeemSuccess(false);
      setRedeemMessage('❌ Invalid promotion code. Please verify your code and try again.');
    }
    setRedeemCode('');
  };

  const executeWatchAd = () => {
    setIsAdWatching(true);
    setTimeout(() => {
      onWatchAd();
      setIsAdWatching(false);
    }, 2000); // 2 seconds simulated ad timer
  };

  return (
    <div className="space-y-6 max-w-md mx-auto">
      {/* Visual Identity Profile Header */}
      <div className="flex flex-col items-center p-5 bg-gradient-to-r from-pink-950/40 to-indigo-950/20 border border-pink-500/20 rounded-2xl text-center relative overflow-hidden">
        {isPremium && (
          <span className="absolute top-3 right-3 text-[10px] px-2.5 py-1 bg-amber-500 text-gray-950 rounded-full font-bold flex items-center space-x-1 uppercase animate-pulse shadow-md select-none">
            <Award size={10} />
            <span>VIP Premium</span>
          </span>
        )}

        <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-pink-500 to-indigo-500 flex items-center justify-center text-white text-xl font-bold border-2 border-gray-900 shadow-lg">
          {profile.fullName ? profile.fullName.charAt(0).toUpperCase() : <User />}
        </div>

        <h2 className="text-base font-bold text-gray-100 mt-2">
          {profile.fullName || 'Guest Student'}
        </h2>
        <p className="text-xs text-gray-400 font-mono italic">
          Field: {profile.studyField || 'Unconfigured Profile'}
        </p>
      </div>

      {/* Editing Setup Form */}
      <div className="bg-[#151821] border border-gray-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-xs font-bold text-gray-250 uppercase tracking-wider font-mono">
          Configure Profile setup
        </h3>

        <form onSubmit={handleSaveProfile} className="space-y-3 font-sans">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Full Name</label>
            <input
              type="text"
              value={editingName}
              onChange={(e) => setEditingName(e.target.value)}
              placeholder="e.g. Bhavesh Nair"
              className="w-full text-xs p-2.5 bg-gray-950 border border-gray-850 rounded-lg text-gray-200 outline-none focus:border-pink-500/40"
            />
          </div>

          <div className="space-y-3 font-sans">
            {/* Academic Status selection */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                Academic Status
              </label>
              <select
                value={
                  editingType === 'school'
                    ? 'school'
                    : (editingField === 'Engineering' ? 'engineering' : 'college')
                }
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === 'school') {
                    setEditingType('school');
                    setEditingClass('Standard 10');
                    setEditingField('Schooling');
                  } else if (val === 'engineering') {
                    setEditingType('college');
                    setEditingClass('1st Year');
                    setEditingField('Engineering');
                  } else {
                    setEditingType('college');
                    setEditingClass('1st Year');
                    setEditingField('BCA');
                  }
                }}
                className="w-full text-xs p-2.5 bg-gray-950 border border-gray-850 rounded-lg text-gray-200"
              >
                <option value="school">🎒 School Student</option>
                <option value="college">🎓 College Student (General)</option>
                <option value="engineering">🚀 Engineering Student</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* Class / Year of Study selection */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">
                  Class / Year
                </label>
                <select
                  value={editingClass}
                  onChange={(e) => setEditingClass(e.target.value)}
                  className="w-full text-xs p-2.5 bg-gray-950 border border-gray-850 rounded-lg text-gray-200"
                >
                  {editingType === 'school' ? (
                    <>
                      <option value="Standard 6">6th Grade</option>
                      <option value="Standard 8">8th Grade</option>
                      <option value="Standard 10">10th Grade</option>
                      <option value="Standard 12">12th Grade</option>
                    </>
                  ) : (
                    <>
                      <option value="1st Year">1st Year / Freshman</option>
                      <option value="2nd Year">2nd Year / Sophomore</option>
                      <option value="3rd Year">3rd Year / Junior</option>
                      <option value="4th Year">4th Year / Senior</option>
                    </>
                  )}
                </select>
              </div>

              {/* Subject Track Selection */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">
                  Subject Track
                </label>
                {editingType === 'school' ? (
                  <input
                    type="text"
                    disabled
                    value="General Studies"
                    className="w-full p-2.5 bg-gray-900 border border-gray-850 rounded-lg text-gray-500 text-xs outline-none select-none"
                  />
                ) : editingField === 'Engineering' ? (
                  <input
                    type="text"
                    disabled
                    value="Engineering"
                    className="w-full p-2.5 bg-gray-900 border border-gray-850 rounded-lg text-cyan-400 font-medium text-xs outline-none select-none"
                  />
                ) : (
                  <select
                    value={editingField}
                    onChange={(e) => setEditingField(e.target.value)}
                    className="w-full text-xs p-2.5 bg-gray-950 border border-gray-850 rounded-lg text-gray-200"
                  >
                    <option value="BCA">BCA (Comp. Applications)</option>
                    <option value="Web Developer">Web Developer</option>
                    <option value="B.Sc">B.Sc (Science)</option>
                    <option value="B.Com">B.Com (Commerce)</option>
                    <option value="Other">Other Specialty</option>
                  </select>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center pt-2">
            {saveSuccess ? (
              <span className="text-[10px] text-emerald-400 font-semibold flex items-center space-x-1 animate-pulse">
                <CheckCircle size={12} />
                <span>Profile updated locally!</span>
              </span>
            ) : (
              <span></span>
            )}

            <button
              type="submit"
              className="px-4 py-2 bg-pink-500 hover:bg-pink-400 text-gray-950 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              Update Details
            </button>
          </div>
        </form>
      </div>

      {/* Promotion / Coupon System */}
      <div className="bg-[#151821] border border-gray-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-xs font-bold text-amber-400 flex items-center space-x-2 uppercase font-mono">
          <Gift size={15} />
          <span>Promo Code Activation</span>
        </h3>
        <p className="text-[10px] text-gray-400 leading-relaxed leading-sans">
          Have an invitation or redeem coupon code? Enter it below to unlock premium features and academic tools instantly.
        </p>

        <div className="flex space-x-2">
          <input
            type="text"
            value={redeemCode}
            onChange={(e) => setRedeemCode(e.target.value)}
            placeholder="Enter promo code..."
            className="flex-1 text-xs p-2.5 bg-gray-950 border border-gray-850 rounded-xl text-yellow-300 font-mono outline-none focus:border-amber-500/40"
          />
          <button
            onClick={handleApplyRedeem}
            className="px-4 bg-amber-500 hover:bg-amber-400 text-gray-950 text-xs font-bold rounded-xl transition cursor-pointer"
          >
            Redeem
          </button>
        </div>

        {redeemMessage && (
          <div
            className={`p-3 rounded-xl text-xs flex items-start space-x-1.5 leading-relaxed ${
              redeemSuccess ? 'bg-emerald-950/20 text-emerald-400 border border-emerald-500/20' : 'bg-rose-950/20 text-rose-350 border border-rose-500/20'
            }`}
          >
            {redeemSuccess ? <CheckCircle size={14} className="shrink-0 mt-0.5" /> : <AlertCircle size={14} className="shrink-0 mt-0.5" />}
            <span className="text-[10px] sm:text-xs">{redeemMessage}</span>
          </div>
        )}
      </div>

      {/* Ad Solve Earning System (if not Premium) */}
      {!isPremium ? (
        <div className="bg-[#151821] border border-gray-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-cyan-400 uppercase font-mono flex items-center space-x-1.5">
              <Video size={15} />
              <span>Solve Credit Booster</span>
            </h3>
            <span className="text-[10px] font-mono text-gray-500">Ad Progress: {adProgress}/3</span>
          </div>
          <p className="text-[10px] text-gray-400 leading-relaxed font-sans">
            Every 3 short ads you watch earns you +1 Solve. Unlimited earns allowed!
          </p>

          {/* Progress Visual */}
          <div className="w-full bg-gray-950 rounded-full h-2.5 overflow-hidden border border-gray-900">
            <div
              className="bg-cyan-400 h-full rounded-full transition-all duration-300"
              style={{ width: `${(adProgress / 3) * 100}%` }}
            ></div>
          </div>

          <button
            onClick={executeWatchAd}
            disabled={isAdWatching}
            className="w-full py-2 bg-cyan-950/40 hover:bg-cyan-950/60 text-cyan-300 hover:text-cyan-200 border border-cyan-500/35 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-40 transition"
          >
            {isAdWatching ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
                <span className="text-[10px] md:text-xs">Watching Ad video stream (3s)...</span>
              </>
            ) : (
              <>
                <Video size={13} />
                <span className="text-[10px] md:text-xs">Watch Ad Stream (+1 Progress Credit)</span>
              </>
            )}
          </button>
        </div>
      ) : (
        <div className="p-4 bg-amber-950/15 border border-amber-500/20 rounded-2xl flex items-center space-x-3">
          <div className="p-2.5 bg-amber-950 rounded-xl text-amber-400">
            <Sparkles size={18} className="animate-pulse" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-amber-400">Ad-Free Mode Completely On</h4>
            <p className="text-[10px] text-gray-400 mt-0.5">Solve limitations & sponsor ad modules removed completely!</p>
          </div>
        </div>
      )}

      {/* Premium Upgrades Purchase Mock */}
      {!isPremium && (
        <div className="bg-gradient-to-tr from-[#151821] to-[#1c2130] border border-amber-500/20 rounded-2xl p-5 space-y-3.5">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[9px] font-bold text-amber-500 uppercase tracking-widest font-mono">Best Value</span>
              <h3 className="text-sm font-bold text-white flex items-center space-x-1 mt-0.5">
                <Award size={15} className="text-amber-400" />
                <span>Unlimited Solves VIP</span>
              </h3>
            </div>
            <span className="text-sm font-black text-amber-400 font-mono">₹10/month</span>
          </div>

          <div className="space-y-1.5 text-[10px] text-gray-300">
            <p className="flex items-center space-x-1.5">
              <CheckCircle size={10} className="text-amber-400 shrink-0" />
              <span>100% Unlimited AI Solves & Transpiles</span>
            </p>
            <p className="flex items-center space-x-1.5">
              <CheckCircle size={10} className="text-amber-400 shrink-0" />
              <span>Full Ad-Free Mode & background speed optimizations</span>
            </p>
            <p className="flex items-center space-x-1.5">
              <CheckCircle size={10} className="text-amber-400 shrink-0" />
              <span>Priority Access with raw thinking levels</span>
            </p>
          </div>

          <button
            onClick={onUpgradeToPremium}
            className="w-full py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 font-black text-gray-950 text-xs rounded-xl flex items-center justify-center space-x-1 transition cursor-pointer"
          >
            <span>Activate Premium Membership</span>
            <ArrowRight size={12} />
          </button>
        </div>
      )}

      {/* Restart Credits & Daily Score */}
      <div className="bg-[#151821] border border-gray-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-xs font-bold text-rose-450 uppercase font-mono flex items-center space-x-1.5">
          <RotateCcw size={15} />
          <span>Quick System Restart</span>
        </h3>
        <p className="text-[10px] text-gray-400 leading-relaxed font-sans mt-1">
          Easily reset your solve credits and clear predictions/quiz scores to start the learning challenge fresh.
        </p>
        <button
          onClick={() => {
            if (onResetCreditsAndScores) {
              onResetCreditsAndScores();
            } else {
              localStorage.setItem('codesolver_solves', '3');
              localStorage.setItem('codesolver_ad_progress', '0');
              localStorage.removeItem('codesolver_tutorial_answers');
              window.dispatchEvent(new Event('codesolver_reset_quizzes'));
            }
            alert("Credits & quiz progress restarted successfully!");
          }}
          type="button"
          className="w-full py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-350 border border-rose-500/25 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 cursor-pointer transition"
        >
          <RotateCcw size={13} />
          <span className="text-[10px] md:text-xs">Restart Credits & Score</span>
        </button>
      </div>

      {/* Logout button */}
      <div className="flex justify-center pt-2">
        <button
          onClick={onLogout}
          className="text-xs text-gray-500 hover:text-gray-300 flex items-center space-x-1.5"
        >
          <LogOut size={13} />
          <span>Exit student session</span>
        </button>
      </div>
    </div>
  );
}
