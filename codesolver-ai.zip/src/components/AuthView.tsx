/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AuthView.tsx - Custom high-contrast Multi-step Onboarding Flow
 */

import React, { useState } from 'react';
import { User, Mail, ShieldAlert, Sparkles, LogIn, ArrowRight, ArrowLeft, AppWindow, BookOpen, GraduationCap } from 'lucide-react';
import { UserProfile } from '../types';

interface AuthViewProps {
  onAuthSuccess: (profile: UserProfile) => void;
}

export default function AuthView({ onAuthSuccess }: AuthViewProps) {
  const [step, setStep] = useState<'signin' | 'details'>('signin');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [logoLoaded, setLogoLoaded] = useState(false);

  const [userFields, setUserFields] = useState<UserProfile>({
    fullName: '',
    userType: 'college',
    classYear: '1st Year',
    studyField: 'Engineering',
  });

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput.trim() || !passwordInput.trim()) {
      return;
    }
    // Advance to Step 2: Student profile details setup page
    setStep('details');
  };

  const handleCompleteSetup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userFields.fullName.trim()) {
      return;
    }
    
    // Complete setup, save profile, and transition to Home Page
    onAuthSuccess({
      ...userFields,
      fullName: userFields.fullName.trim(),
      email: emailInput.trim(),
    });
  };

  return (
    <div className="w-full max-w-sm mx-auto p-4 space-y-6">
      {/* Branding Logo placement top center */}
      <div className="flex flex-col items-center space-y-3 pt-4 text-center">
        <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-500 p-[1.5px] overflow-hidden shadow-xl shadow-cyan-950/20">
          <div className="w-full h-full bg-[#0f1117] rounded-2xl flex items-center justify-center overflow-hidden relative">
            <img
              src="/logo.png"
              alt="CodeSolver AI"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onLoad={() => setLogoLoaded(true)}
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                setLogoLoaded(false);
              }}
            />
            {/* SVG Logo fallback if logo fails loading */}
            {!logoLoaded && (
              <div className="absolute inset-0 flex items-center justify-center p-3 text-cyan-400">
                <AppWindow size={36} />
              </div>
            )}
          </div>
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-100 tracking-tight">CodeSolver AI</h1>
          <p className="text-xs text-gray-400 font-mono mt-0.5">Tutoring & Solver Platform</p>
        </div>
      </div>

      {/* Main Container Card */}
      <div className="bg-[#151821] border border-gray-800 rounded-2xl p-6 shadow-xl space-y-5">
        
        {step === 'signin' ? (
          /* STEP 1: SIGN-IN PAGE WITH OPTION TO SIGN IN LATER */
          <div className="space-y-4">
            <div className="text-center space-y-1">
              <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-widest font-mono">Step 1 of 2</span>
              <h3 className="text-sm font-bold text-gray-200">
                Sign In to Your Workspace
              </h3>
              <p className="text-[10px] text-gray-500">
                Please enter your credentials, or choose to skip and sign in later!
              </p>
            </div>

            <form onSubmit={handleNextStep} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-300 uppercase tracking-widest font-mono">
                  Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="student@university.edu"
                    className="w-full p-2.5 pl-9 bg-gray-950 border border-gray-800 rounded-lg text-xs text-gray-200 outline-none focus:border-cyan-500/40 font-mono"
                  />
                  <Mail size={14} className="absolute left-3 top-3.5 text-gray-600" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-300 uppercase tracking-widest font-mono">
                  Secret Password
                </label>
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••"
                  className="w-full p-2.5 bg-gray-950 border border-gray-800 rounded-lg text-xs text-gray-200 outline-none focus:border-cyan-500/40 font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-indigo-500 hover:from-cyan-600 hover:to-indigo-600 font-bold text-[#0f1117] text-xs rounded-xl flex items-center justify-center space-x-1.5 shadow-lg select-none cursor-pointer scale-100 hover:scale-[1.01] transition"
              >
                <span>Continue is Verified User</span>
                <ArrowRight size={14} />
              </button>
            </form>

            <div className="relative flex py-2 items-center">
              <div className="flex-grow border-t border-gray-900"></div>
              <span className="flex-shrink mx-3 text-[9px] text-gray-600 font-mono uppercase tracking-widest">Or</span>
              <div className="flex-grow border-t border-gray-900"></div>
            </div>

            <button
              onClick={() => {
                // Instantly advance to profile setup step as guest
                setStep('details');
              }}
              className="w-full py-2.5 bg-gray-900/60 border border-gray-800/80 hover:bg-gray-850 hover:border-gray-700 font-bold text-cyan-300 hover:text-cyan-200 text-xs rounded-xl flex items-center justify-center space-x-1 transition select-none cursor-pointer"
            >
              <span>Sign In Later (Skip Now)</span>
              <ArrowRight size={14} className="text-cyan-400" />
            </button>

            <div className="pt-2 text-center text-[10px] text-gray-600 flex items-center justify-center space-x-1 border-t border-gray-850/45">
              <ShieldAlert size={11} />
              <span>Full local sandbox environment configuration active</span>
            </div>
          </div>
        ) : (
          /* STEP 2: STUDENT PROFILE CONFIGURATION PAGE */
          <div className="space-y-4">
            <div className="text-center space-y-1">
              <div className="flex items-center justify-center space-x-2">
                <button 
                  onClick={() => setStep('signin')}
                  className="text-gray-500 hover:text-gray-300 flex items-center space-x-0.5 text-[10px] outline-none"
                >
                  <ArrowLeft size={10} />
                  <span>Back</span>
                </button>
                <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest font-mono">Step 2 of 2</span>
              </div>
              <h3 className="text-sm font-bold text-gray-200">
                Personalize Your Academic Profile
              </h3>
              <p className="text-[10px] text-gray-500">
                Tell us your name, class level, and field / track to configure your solvers
              </p>
            </div>

            <form onSubmit={handleCompleteSetup} className="space-y-4">
              <div className="space-y-1.5 font-sans">
                <label className="text-[10px] font-bold text-gray-300 uppercase tracking-widest font-mono">
                  Your Full Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={userFields.fullName}
                    onChange={(e) => setUserFields({ ...userFields, fullName: e.target.value })}
                    placeholder="E.g., Samantha Carter"
                    className="w-full p-2.5 pl-9 bg-gray-950 border border-gray-800 rounded-lg text-xs text-gray-200 outline-none focus:border-indigo-500/40"
                  />
                  <User size={14} className="absolute left-3 top-3.5 text-gray-600" />
                </div>
              </div>

              <div className="space-y-3">
                {/* Academic Status selection */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider font-mono">
                    Academic Status
                  </label>
                  <select
                    value={
                      userFields.userType === 'school'
                        ? 'school'
                        : (userFields.studyField === 'Engineering' ? 'engineering' : 'college')
                    }
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === 'school') {
                        setUserFields({
                          fullName: userFields.fullName,
                          userType: 'school',
                          classYear: 'Standard 10',
                          studyField: 'Schooling'
                        });
                      } else if (val === 'engineering') {
                        setUserFields({
                          fullName: userFields.fullName,
                          userType: 'college',
                          classYear: '1st Year',
                          studyField: 'Engineering'
                        });
                      } else {
                        setUserFields({
                          fullName: userFields.fullName,
                          userType: 'college',
                          classYear: '1st Year',
                          studyField: 'BCA'
                        });
                      }
                    }}
                    className="w-full p-2.5 bg-gray-950 border border-gray-800 rounded-lg text-gray-200 outline-none text-xs focus:border-indigo-500/40 cursor-pointer"
                  >
                    <option value="school">🎒 School Student</option>
                    <option value="college">🎓 College Student (General)</option>
                    <option value="engineering">🚀 Engineering Student</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {/* Class / Year of Study selection */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider font-mono">
                      Class / Year
                    </label>
                    <select
                      value={userFields.classYear}
                      onChange={(e) => setUserFields({ ...userFields, classYear: e.target.value })}
                      className="w-full p-2.5 bg-gray-950 border border-gray-800 rounded-lg text-gray-200 outline-none text-xs focus:border-indigo-500/40 cursor-pointer"
                    >
                      {userFields.userType === 'school' ? (
                        <>
                          <option value="Standard 6">6th Grade</option>
                          <option value="Standard 8">8th Grade</option>
                          <option value="Standard 10">10th Grade</option>
                          <option value="Standard 12">12th Grade</option>
                        </>
                      ) : (
                        <>
                          <option value="1st Year">1st Year / Freshman</option>
                          <option value="2nd Year">2nd Year / Sophomore</option>
                          <option value="3rd Year">3rd Year / Junior</option>
                          <option value="4th Year">4th Year / Senior</option>
                        </>
                      )}
                    </select>
                  </div>

                  {/* Subject Track Selection */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider font-mono">
                      Subject Track
                    </label>
                    {userFields.userType === 'school' ? (
                      <input
                        type="text"
                        disabled
                        value="General Studies"
                        className="w-full p-2.5 bg-gray-900 border border-gray-850 rounded-lg text-gray-500 text-xs outline-none select-none"
                      />
                    ) : userFields.studyField === 'Engineering' ? (
                      <input
                        type="text"
                        disabled
                        value="Engineering"
                        className="w-full p-2.5 bg-gray-900 border border-gray-850 rounded-lg text-cyan-400 font-medium text-xs outline-none select-none"
                      />
                    ) : (
                      <select
                        value={userFields.studyField}
                        onChange={(e) => setUserFields({ ...userFields, studyField: e.target.value })}
                        className="w-full p-2.5 bg-gray-950 border border-gray-800 rounded-lg text-gray-200 outline-none text-xs focus:border-indigo-500/40 cursor-pointer"
                      >
                        <option value="BCA">BCA (Comp. Applications)</option>
                        <option value="Web Developer">Web Developer</option>
                        <option value="B.Sc">B.Sc (Science)</option>
                        <option value="B.Com">B.Com (Commerce)</option>
                        <option value="Other">Other Specialty</option>
                      </select>
                    )}
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 font-bold text-gray-100 text-xs rounded-xl flex items-center justify-center space-x-1.5 shadow-lg select-none cursor-pointer transition mt-2"
              >
                <Sparkles size={14} className="text-pink-300 animate-spin" style={{ animationDuration: '3s' }} />
                <span>Complete Setup & Launch Home</span>
              </button>
            </form>
          </div>
        )}

      </div>
    </div>
  );
}
