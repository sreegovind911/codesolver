/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Bot, Camera, Copy, Check, Send, Sparkles, BookOpen, Calculator, Globe, Code, PenTool, MessageSquare, GraduationCap, X } from 'lucide-react';
import VoiceInputButton from '../VoiceInputButton';

interface TutorProps {
  onCameraClick: (onExtract: (text: string) => void) => void;
  isPremium: boolean;
  onGoToPremium?: () => void;
}

export default function Tutor({
  onCameraClick,
  isPremium,
  onGoToPremium,
}: TutorProps) {
  // Toggle between General Subject Tutor and Programming CS Q&A Classroom
  const [subTab, setSubTab] = useState<'mentor' | 'qa'>('mentor');

  // Multi-subject mentor states
  const [subject, setSubject] = useState<'Math' | 'Science' | 'English' | 'Computer' | 'GK'>('Math');
  const [query, setQuery] = useState(() => localStorage.getItem('codesolver_m_query') || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [response, setResponse] = useState<string | null>(() => localStorage.getItem('codesolver_m_response') || null);
  const [copied, setCopied] = useState(false);

  // Programming Q&A states
  const [question, setQuestion] = useState(() => localStorage.getItem('codesolver_qa_question') || '');
  const [qaLoading, setQaLoading] = useState(false);
  const [qaError, setQaError] = useState<string | null>(null);
  const [qaAnswer, setQaAnswer] = useState<string | null>(() => localStorage.getItem('codesolver_qa_answer') || null);
  const [qaCopied, setQaCopied] = useState(false);

  // Sync state helpers
  const handleSetQuery = (val: string) => {
    setQuery(val);
    localStorage.setItem('codesolver_m_query', val);
  };
  const handleSetResponse = (val: string | null) => {
    setResponse(val);
    if (val) localStorage.setItem('codesolver_m_response', val);
    else localStorage.removeItem('codesolver_m_response');
  };
  const handleSetQuestion = (val: string) => {
    setQuestion(val);
    localStorage.setItem('codesolver_qa_question', val);
  };
  const handleSetQaAnswer = (val: string | null) => {
    setQaAnswer(val);
    if (val) localStorage.setItem('codesolver_qa_answer', val);
    else localStorage.removeItem('codesolver_qa_answer');
  };

  const handleConsult = async () => {
    if (!query.trim()) return;
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, query }),
      });

      const data = await res.json();
      if (res.ok) {
        handleSetResponse(data.text);
      } else {
        throw new Error(data.error || 'Server tutor declined request');
      }
    } catch (err: any) {
      setError(err.message || 'Connecting to classroom tutor failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleAskQA = async () => {
    if (!question.trim()) return;
    setQaError(null);
    setQaLoading(true);

    try {
      const response = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question }),
      });

      const data = await response.json();
      if (response.ok) {
        handleSetQaAnswer(data.text);
      } else {
        throw new Error(data.error || 'Server Q&A call failed');
      }
    } catch (err: any) {
      setQaError(err.message || 'Connecting to classroom server failed.');
    } finally {
      setQaLoading(false);
    }
  };

  const handleCopy = () => {
    if (response) {
      navigator.clipboard.writeText(response);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCopyQA = () => {
    if (qaAnswer) {
      navigator.clipboard.writeText(qaAnswer);
      setQaCopied(true);
      setTimeout(() => setQaCopied(false), 2000);
    }
  };

  const triggerCameraScanner = () => {
    onCameraClick((extractedText) => {
      handleSetQuery(extractedText);
    });
  };

  const triggerCameraScannerQA = () => {
    onCameraClick((extractedText) => {
      handleSetQuestion(extractedText);
    });
  };

  const handleResetWorkspace = () => {
    handleSetQuery('');
    handleSetResponse(null);
    handleSetQuestion('');
    handleSetQaAnswer(null);
    setError(null);
    setQaError(null);
  };

  const subjects = [
    { id: 'Math' as const, label: 'Mathematics', icon: Calculator, color: 'border-fuchsia-500 text-fuchsia-400 bg-fuchsia-950/20' },
    { id: 'Science' as const, label: 'Science & Physics', icon: Globe, color: 'border-cyan-500 text-cyan-400 bg-cyan-950/20' },
    { id: 'English' as const, label: 'English Literature', icon: PenTool, color: 'border-amber-500 text-amber-400 bg-amber-950/20' },
    { id: 'Computer' as const, label: 'Computer Science', icon: Code, color: 'border-teal-500 text-teal-400 bg-teal-950/20' },
    { id: 'GK' as const, label: 'General Knowledge', icon: BookOpen, color: 'border-indigo-500 text-indigo-400 bg-indigo-950/20' },
  ];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="p-5 bg-gradient-to-r from-fuchsia-950/40 to-indigo-950/20 border border-fuchsia-500/20 rounded-2xl">
        <h2 className="text-xl font-bold text-fuchsia-400 flex items-center space-x-2">
          <Bot className="animate-pulse" size={20} />
          <span>General Subject AI Tutor & Q&A</span>
        </h2>
        <p className="text-xs text-gray-300 mt-1">
          Chat with our multi-subject master mentor and CS classroom expert! Secure help with Math, Physics, English essays, or complex software development doubts.
        </p>
      </div>

      {/* Sub tabs navigation */}
      <div className="flex items-center justify-between border-b border-gray-850 pb-2">
        <div className="flex space-x-1 sm:space-x-2 bg-gray-950 p-1 border border-gray-850 rounded-lg">
          <button
            onClick={() => setSubTab('mentor')}
            className={`px-3 py-1.5 text-xs font-semibold font-mono rounded-md transition cursor-pointer flex items-center space-x-1.5 ${
              subTab === 'mentor'
                ? 'bg-fuchsia-950/60 border border-fuchsia-500/20 text-fuchsia-450 font-bold'
                : 'text-gray-400 hover:text-white border border-transparent'
            }`}
          >
            <GraduationCap size={13} />
            <span>Subject Mentor</span>
          </button>
          <button
            onClick={() => setSubTab('qa')}
            className={`px-3 py-1.5 text-xs font-semibold font-mono rounded-md transition cursor-pointer flex items-center space-x-1.5 ${
              subTab === 'qa'
                ? 'bg-emerald-950/60 border border-emerald-500/20 text-emerald-400 font-bold'
                : 'text-gray-400 hover:text-white border border-transparent'
            }`}
          >
            <MessageSquare size={13} />
            <span>Programming Classroom Q&A</span>
          </button>
        </div>

        <button
          onClick={handleResetWorkspace}
          className="text-[10px] text-gray-500 hover:text-gray-300 font-mono flex items-center space-x-1"
        >
          <X size={10} />
          <span>Reset All</span>
        </button>
      </div>

      {subTab === 'mentor' ? (
        /* MENTOR MODE */
        <div className="space-y-6">
          {/* Subject selectors */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block font-mono">
              Select Academic Discipline:
            </span>
            <div className="flex flex-wrap gap-2">
              {subjects.map((sub) => {
                const IconComponent = sub.icon;
                const isSelected = subject === sub.id;
                return (
                  <button
                    key={sub.id}
                    onClick={() => setSubject(sub.id)}
                    className={`py-2 px-3 border rounded-xl text-xs font-semibold flex items-center space-x-2 transition-all cursor-pointer ${
                      isSelected
                        ? `${sub.color} scale-105 border-fuchsia-500/80 ring-1 ring-fuchsia-500/30`
                        : 'border-gray-800 text-gray-400 hover:text-gray-200 hover:border-gray-700 bg-transparent'
                    }`}
                  >
                    <IconComponent size={14} />
                    <span>{sub.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Input container */}
          <div className="bg-[#151821] border border-gray-800 rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between text-xs font-semibold text-gray-400">
              <span>Ask {subject} Doubts or homework problems:</span>
              <button
                onClick={() => handleSetQuery('')}
                className="text-[10px] text-gray-500 hover:text-gray-300"
              >
                Clear
              </button>
            </div>

            {/* Textbox with internal camera OCR scan */}
            <div className="relative">
              <textarea
                value={query}
                onChange={(e) => handleSetQuery(e.target.value)}
                placeholder={`Type your ${subject} query... E.g., ${
                  subject === 'Math'
                    ? "'Explain steps to find eigenvalues of a 2x2 matrix'"
                    : subject === 'Science'
                    ? "'Explain the transition states in chemical thermodynamics and standard enthalpy'"
                    : "'How do you correct dangling modifiers in English essays with examples?'"
                }`}
                className="w-full min-h-[140px] p-3.5 pb-16 bg-gray-950 border border-gray-800 rounded-xl text-xs md:text-sm text-fuchsia-300 placeholder-gray-700 outline-none focus:border-fuchsia-500/40 resize-y"
              />

              <div className="absolute bottom-3 right-3 flex items-center space-x-2">
                <VoiceInputButton
                  colorTheme="fuchsia"
                  onTranscript={(text) => handleSetQuery(query ? query + ' ' + text : text)}
                />
                <button
                  onClick={triggerCameraScanner}
                  type="button"
                  title="Scan textbook equation with camera"
                  className="p-2 bg-fuchsia-950/70 hover:bg-fuchsia-900 border border-fuchsia-400/30 rounded-xl text-fuchsia-400 flex items-center justify-center transition group cursor-pointer"
                >
                  <Camera size={14} className="group-hover:scale-110 transition" />
                </button>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleConsult}
                disabled={loading || !query.trim()}
                className="px-6 py-2.5 bg-fuchsia-500 hover:bg-fuchsia-400 disabled:bg-gray-800 disabled:text-gray-500 text-gray-955 font-bold rounded-xl flex items-center space-x-2 transition cursor-pointer"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-gray-950 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-xs">Tutor is drafting reply...</span>
                  </>
                ) : (
                  <>
                    <span className="text-xs">Explain Concept</span>
                    <Send size={12} />
                  </>
                )}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-3 bg-rose-950/20 border border-rose-500/20 rounded-xl text-rose-300 text-xs text-center">
              {error}
            </div>
          )}

          {/* Tutor Response */}
          {response && !loading && (
            <div className="bg-[#151821] border border-fuchsia-500/20 rounded-2xl overflow-hidden shadow-xl">
              <div className="p-4 bg-[#0f1117] border-b border-gray-800 flex items-center justify-between">
                <span className="text-xs font-bold text-fuchsia-400 flex items-center space-x-1.5">
                  <Sparkles size={14} className="text-fuchsia-400" />
                  <span>Explanation from AI {subject} Tutor</span>
                </span>

                <button
                  onClick={handleCopy}
                  className="p-1 px-2.5 text-xs bg-gray-950 hover:bg-gray-900 text-gray-400 hover:text-white border border-gray-800 rounded-lg flex items-center space-x-1.5 transition cursor-pointer"
                >
                  {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-4 md:p-6 overflow-y-auto max-h-[500px] text-xs md:text-sm text-gray-300 font-sans leading-relaxed space-y-4">
                {response.split('\n').map((line, idx) => {
                  if (line.startsWith('## ') || line.startsWith('### ')) {
                    return (
                      <h4 key={idx} className="font-bold text-gray-100 text-sm md:text-base text-fuchsia-400 mt-4 mb-2">
                        {line.replace(/#/g, '').trim()}
                      </h4>
                    );
                  }
                  const isNumberedList = /^\d+\./.test(line);
                  return (
                    <div
                      key={idx}
                      className={`text-gray-300 ${isNumberedList ? 'pl-2 border-l-2 border-fuchsia-950 text-gray-200 font-medium' : ''}`}
                    >
                      {line}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Q&A MODE */
        <div className="space-y-6">
          {/* Input Group */}
          <div className="bg-[#151821] border border-gray-800 rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-300">Type Your Computer Science Query:</span>
              <button
                onClick={() => handleSetQuestion('')}
                className="text-[10px] text-gray-500 hover:text-gray-300 flex items-center space-x-1 cursor-pointer"
              >
                Clear
              </button>
            </div>

            {/* Input Text Box with Camera trigger inside */}
            <div className="relative">
              <textarea
                value={question}
                onChange={(e) => handleSetQuestion(e.target.value)}
                placeholder="E.g., 'What is time complexity of QuickSort on already sorted arrays?' or 'Explain binary searches in layman terms with visual examples.'"
                className="w-full min-h-[140px] p-3.5 pb-16 bg-gray-950 border border-gray-800 rounded-xl text-xs md:text-sm text-emerald-300 placeholder-gray-700 outline-none focus:border-emerald-500/40 resize-y"
              />

              <div className="absolute bottom-3 right-3 flex items-center space-x-2">
                <VoiceInputButton
                  colorTheme="emerald"
                  onTranscript={(text) => handleSetQuestion(question ? question + ' ' + text : text)}
                />
                <button
                  onClick={triggerCameraScannerQA}
                  type="button"
                  title="Scan code question from book page"
                  className="p-2 bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-400/30 rounded-xl text-emerald-400 flex items-center justify-center transition group cursor-pointer"
                >
                  <Camera size={14} className="group-hover:scale-110 transition" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end">
              <button
                onClick={handleAskQA}
                disabled={qaLoading || !question.trim()}
                className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:bg-gray-800 disabled:text-gray-500 text-gray-955 font-bold rounded-xl flex items-center space-x-2 transition cursor-pointer"
              >
                {qaLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-gray-950 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-xs">Consulting Expert...</span>
                  </>
                ) : (
                  <>
                    <span className="text-xs font-bold">Ask doubts</span>
                    <Send size={12} />
                  </>
                )}
              </button>
            </div>
          </div>

          {qaError && (
            <div className="p-3 bg-rose-950/20 border border-rose-500/20 rounded-xl text-rose-300 text-xs text-center">
              {qaError}
            </div>
          )}

          {/* Answer container */}
          {qaAnswer && !qaLoading && (
            <div className="bg-[#151821] border border-emerald-500/20 rounded-2xl overflow-hidden shadow-xl">
              <div className="p-4 bg-[#0f1117] border-b border-gray-800 flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 flex items-center space-x-1.5">
                  <Sparkles size={14} className="text-emerald-400" />
                  <span>Academic Explanation</span>
                </span>

                <button
                  onClick={handleCopyQA}
                  className="p-1 px-2.5 text-xs bg-gray-950 hover:bg-gray-900 text-gray-400 hover:text-white border border-gray-800 rounded-lg flex items-center space-x-1.5 transition cursor-pointer"
                >
                  {qaCopied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  <span>{qaCopied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-4 md:p-6 overflow-y-auto max-h-[500px] text-xs md:text-sm text-gray-300 font-sans leading-relaxed space-y-4">
                {qaAnswer.split('\n').map((line, idx) => {
                  if (line.startsWith('## ') || line.startsWith('### ')) {
                    return (
                      <h4 key={idx} className="font-bold text-gray-100 text-sm md:text-base text-emerald-400 mt-4 mb-2">
                        {line.replace(/#/g, '').trim()}
                      </h4>
                    );
                  }
                  const isNumberedList = /^\d+\./.test(line);
                  return (
                    <div
                      key={idx}
                      className={`text-gray-300 ${isNumberedList ? 'pl-2 border-l-2 border-emerald-950 text-gray-200' : ''}`}
                    >
                      {line}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
