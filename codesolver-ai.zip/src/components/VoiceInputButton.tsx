/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff } from 'lucide-react';

interface VoiceInputButtonProps {
  onTranscript: (text: string) => void;
  className?: string;
  colorTheme?: 'emerald' | 'cyan' | 'purple' | 'indigo' | 'rose' | 'fuchsia' | 'teal';
}

export default function VoiceInputButton({
  onTranscript,
  className = '',
  colorTheme = 'cyan',
}: VoiceInputButtonProps) {
  const [isListening, setIsListening] = useState(false);
  const [supported, setSupported] = useState(true);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSupported(false);
    }
  }, []);

  const toggleListening = () => {
    if (!supported) {
      alert("Speech recognition is not fully supported in this framing environment. Please ensure microphone permissions are granted.");
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
    } else {
      try {
        const rec = new SpeechRecognition();
        rec.continuous = false;
        rec.interimResults = false;
        rec.lang = 'en-US';

        rec.onstart = () => {
          setIsListening(true);
        };

        rec.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            onTranscript(transcript);
          }
        };

        rec.onerror = (event: any) => {
          console.error("Speech recognition error:", event.error);
          setIsListening(false);
        };

        rec.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = rec;
        rec.start();
      } catch (err) {
        console.error("Failed to start speech recognition:", err);
        setIsListening(false);
      }
    }
  };

  const themeMap = {
    cyan: {
      active: 'bg-cyan-500/20 text-cyan-400 border-cyan-400 animate-pulse',
      idle: 'bg-cyan-950/70 hover:bg-cyan-900 border-cyan-500/30 text-cyan-400',
    },
    emerald: {
      active: 'bg-emerald-500/20 text-emerald-400 border-emerald-400 animate-pulse',
      idle: 'bg-emerald-950/70 hover:bg-emerald-900 border-emerald-400/30 text-emerald-400',
    },
    purple: {
      active: 'bg-purple-500/20 text-purple-400 border-purple-400 animate-pulse',
      idle: 'bg-purple-950/70 hover:bg-purple-900 border-purple-400/30 text-purple-400',
    },
    indigo: {
      active: 'bg-indigo-500/20 text-indigo-400 border-indigo-400 animate-pulse',
      idle: 'bg-indigo-950/70 hover:bg-indigo-900 border-indigo-500/30 text-indigo-400',
    },
    rose: {
      active: 'bg-rose-500/20 text-rose-400 border-rose-400 animate-pulse',
      idle: 'bg-rose-950/70 hover:bg-rose-900 border-rose-400/30 text-rose-400',
    },
    fuchsia: {
      active: 'bg-fuchsia-500/20 text-fuchsia-400 border-fuchsia-400 animate-pulse',
      idle: 'bg-fuchsia-950/70 hover:bg-fuchsia-900 border-fuchsia-400/30 text-fuchsia-400',
    },
    teal: {
      active: 'bg-teal-500/20 text-teal-400 border-teal-400 animate-pulse',
      idle: 'bg-teal-950/70 hover:bg-teal-900 border-teal-500/30 text-teal-400',
    },
  };

  const activeTheme = themeMap[colorTheme] || themeMap.cyan;

  return (
    <button
      onClick={toggleListening}
      type="button"
      title={isListening ? "Listening... click to stop" : "Voice Input (Speech-to-text)"}
      className={`p-2 border rounded-xl flex items-center justify-center transition cursor-pointer group ${
        isListening ? activeTheme.active : activeTheme.idle
      } ${className}`}
    >
      {isListening ? (
        <div className="flex items-center space-x-1.5">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
          </span>
          <MicOff size={14} className="animate-pulse" />
        </div>
      ) : (
        <Mic size={14} className="group-hover:scale-110 transition" />
      )}
    </button>
  );
}
