/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppWindow, Award, Sparkles, X, Trash2, Camera, LogIn, Upload, CheckCircle, Video } from 'lucide-react';
import { AppTab, UserProfile } from './types';

// Component Imports
import BottomNavBar from './components/BottomNavBar';
import CameraOCRModal from './components/CameraOCRModal';
import HomeSolver from './components/Tabs/HomeSolver';
import Converter from './components/Tabs/Converter';
import Debugger from './components/Tabs/Debugger';
import Tutor from './components/Tabs/Tutor';
import Learn from './components/Tabs/Learn';
import ProfileView from './components/ProfileView';
import AuthView from './components/AuthView';

export default function App() {
  // Navigation Routing States - query param based backings
  const [activeTab, setActiveTabState] = useState<AppTab>('home');

  // User details & caches
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('codesolver_profile');
    return saved ? JSON.parse(saved) : {
      fullName: 'Bhavesh Guest',
      userType: 'college',
      classYear: '1st Year',
      studyField: 'Web Developer',
    };
  });

  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem('codesolver_logged_in') === 'true';
  });

  // Premium, solve counters
  const [isPremium, setIsPremium] = useState(() => {
    return localStorage.getItem('codesolver_premium') === 'true';
  });

  const [isAdFree, setIsAdFree] = useState(() => {
    return localStorage.getItem('codesolver_adfree') === 'true';
  });

  const [solvesRemaining, setSolvesRemaining] = useState(() => {
    const saved = localStorage.getItem('codesolver_solves');
    const val = saved ? parseInt(saved, 10) : 3;
    return val <= 0 ? 3 : val;
  });

  const [adProgress, setAdProgress] = useState(() => {
    const saved = localStorage.getItem('codesolver_ad_progress');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [isWatchingHeaderAd, setIsWatchingHeaderAd] = useState(false);

  const handleInstantAdCredit = () => {
    setIsWatchingHeaderAd(true);
    setTimeout(() => {
      setSolvesRemaining((prev) => prev + 1);
      setIsWatchingHeaderAd(false);
    }, 1000);
  };

  // Camera OCR scanner active slot states
  const [cameraModalOpen, setCameraModalOpen] = useState(false);
  const [cameraTargetCallback, setCameraTargetCallback] = useState<((text: string) => void) | null>(null);
  const [logoLoaded, setLogoLoaded] = useState(false);

  // Sync state changes to storage
  useEffect(() => {
    localStorage.setItem('codesolver_profile', JSON.stringify(profile));
    if (
      profile?.email?.toLowerCase() === 'bhaveshbnair9@gmail.com' ||
      profile?.fullName?.toLowerCase().includes('bhavesh')
    ) {
      setIsPremium(false);
      setIsAdFree(false);
    }
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('codesolver_logged_in', isLoggedIn ? 'true' : 'false');
  }, [isLoggedIn]);

  useEffect(() => {
    localStorage.setItem('codesolver_premium', isPremium ? 'true' : 'false');
  }, [isPremium]);

  useEffect(() => {
    localStorage.setItem('codesolver_adfree', isAdFree ? 'true' : 'false');
  }, [isAdFree]);

  useEffect(() => {
    localStorage.setItem('codesolver_solves', solvesRemaining.toString());
  }, [solvesRemaining]);

  useEffect(() => {
    localStorage.setItem('codesolver_ad_progress', adProgress.toString());
  }, [adProgress]);

  // Sync active view triggers to query params so they can simulate multi-page URL routes (convert.html, debug.html etc.)
  const setActiveTab = (tab: AppTab) => {
    const targetTab = tab === 'scan' ? 'book' : tab;
    setActiveTabState(targetTab);
    window.history.pushState(null, '', `?page=${targetTab}`);
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    let page = params.get('page') as AppTab;
    if (page) {
      if (page === 'scan') page = 'book';
      setActiveTabState(page);
    }
  }, []);

  // Solve credits decrement rule: Checked on submit
  const useSolveCredit = (): boolean => {
    if (isPremium) return true;
    if (solvesRemaining > 0) {
      setSolvesRemaining((prev) => prev - 1);
      return true;
    }
    return false;
  };

  // Redeem Promo Codes: bh4ve5h triggers absolute premium
  const handleRedeemCode = (code: string): boolean => {
    if (code.toLowerCase() === 'bh4ve5h') {
      setIsPremium(true);
      setIsAdFree(true);
      return true;
    }
    return false;
  };

  const handleWatchAdReward = () => {
    setAdProgress((prev) => {
      const next = prev + 1;
      if (next >= 3) {
        setSolvesRemaining((s) => s + 1);
        return 0; // reset
      }
      return next;
    });
  };

  // Profile auth triggers
  const handleAuthSuccess = (profileData: UserProfile) => {
    setProfile(profileData);
    setIsLoggedIn(true);
    setActiveTab('home');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setProfile({
      fullName: 'Bhavesh Guest',
      userType: 'college',
      classYear: '1st Year',
      studyField: 'Web Developer',
    });
    setIsPremium(false);
    setIsAdFree(false);
    setSolvesRemaining(3);
    setAdProgress(0);
    setActiveTab('home');
  };

  const handleResetCreditsAndScores = () => {
    setSolvesRemaining(3);
    setAdProgress(0);
    localStorage.removeItem('codesolver_tutorial_answers');
    window.dispatchEvent(new Event('codesolver_reset_quizzes'));
  };

  // Open the global Camera OCR Modal and hold the insert callback
  const handleCameraTrigger = (onExtract: (text: string) => void) => {
    setCameraTargetCallback(() => onExtract);
    setCameraModalOpen(true);
  };

  // Tab scanner direct view states helper
  const [scanImage, setScanImage] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [scanLoader, setScanLoader] = useState(false);

  const handleMainMenuScan = async () => {
    if (!scanImage) return;
    setScanLoader(true);
    setScanResult(null);
    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: scanImage, taskType: 'scan' }),
      });
      const data = await response.json();
      if (response.ok && data.text) {
        setScanResult(data.text);
      } else {
        throw new Error(data.error || 'Transcription output empty');
      }
    } catch (err: any) {
      setScanResult(`Error OCR: ${err.message}`);
    } finally {
      setScanLoader(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f1117] text-gray-100 flex flex-col font-sans">
      {/* Outer wrapper: Centered mobile viewport styling on large screens */}
      <div className="w-full max-w-lg mx-auto bg-[#0b0c10] min-h-screen flex flex-col relative pb-32 border-x border-gray-900/60 shadow-2xl">
        
         {/* TOP BRAND BAR */}
         <header className="sticky top-0 z-30 flex items-center justify-between p-4 bg-[#0f1117]/95 border-b border-gray-800 backdrop-blur-md">
           <div className="flex items-center space-x-2.5 cursor-pointer select-none" onClick={() => isLoggedIn && setActiveTab('home')}>
             <div className="relative w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-500 p-[1.5px] overflow-hidden flex items-center justify-center">
               <div className="w-full h-full bg-[#0f1117] rounded-xl flex items-center justify-center overflow-hidden relative">
                 <img
                   src="/logo.png"
                   alt="CodeSolver AI"
                   className="w-full h-full object-cover"
                   referrerPolicy="no-referrer"
                   onLoad={() => setLogoLoaded(true)}
                   onError={(e) => {
                     e.currentTarget.style.display = 'none';
                     setLogoLoaded(false);
                   }}
                 />
                 {!logoLoaded && (
                   <div className="absolute inset-x-0 inset-y-0 flex items-center justify-center text-cyan-400">
                     <AppWindow size={16} />
                   </div>
                 )}
               </div>
             </div>
             <div>
               <h1 className="text-sm font-black tracking-tight bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent">
                 CodeSolver AI
               </h1>
               <p className="text-[9px] text-gray-500 font-mono tracking-tighter">Academic Companion</p>
             </div>
           </div>
 
           {isLoggedIn && (
             <div className="flex items-center space-x-2 text-xs font-sans">
               {isPremium ? (
                  <span className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-full font-bold flex items-center space-x-1 uppercase text-[9px] tracking-wide shadow-sm animate-pulse">
                    <Award size={10} />
                    <span>Premium VIP</span>
                  </span>
                ) : (
                  <div className="flex items-center space-x-1.5">
                    <div className="px-2.5 py-1 bg-gray-900 border border-gray-800 rounded-lg text-gray-400 block font-semibold text-[10px]">
                      <span>Credits: {solvesRemaining}</span>
                    </div>
                    <button
                      onClick={handleInstantAdCredit}
                      disabled={isWatchingHeaderAd}
                      className="px-2 py-1 bg-amber-500/15 hover:bg-amber-500/30 border border-amber-500/30 text-amber-400 hover:text-amber-300 font-extrabold rounded-lg text-[9px] flex items-center space-x-1 transition cursor-pointer disabled:opacity-50 font-sans"
                    >
                      {isWatchingHeaderAd ? (
                        <>
                          <div className="w-2.5 h-2.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></div>
                          <span>Ad...</span>
                        </>
                      ) : (
                        <>
                          <Video size={10} className="text-amber-400" />
                          <span>Watch Ad (+1)</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            )}
          </header>

        {/* TOP BANNER SPONSOR AD (Visible on free mode) */}
        {isLoggedIn && !isPremium && !isAdFree && (
          <div id="top-banner-sponsor" className="mx-4 mt-3 p-2 px-3 bg-indigo-950/25 border border-indigo-500/20 rounded-xl flex items-center justify-between text-[10px] text-indigo-300 font-sans">
            <span className="truncate">🎯 <strong>Sponsor AD:</strong> Get certified in Python & React with CodeSolver Premium!</span>
            <button
              onClick={() => setActiveTab('profile')}
              className="ml-2 font-bold text-cyan-400 hover:underline shrink-0 text-[9px]"
            >
              Get Premium
            </button>
          </div>
        )}

        {/* MAIN BODY SCROLL INTERACTION */}
        <main className="flex-1 px-4 py-4 space-y-6 font-sans">
          <AnimatePresence mode="wait">
            {!isLoggedIn ? (
              <motion.div
                key="auth-onboarding-wizard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
              >
                <AuthView onAuthSuccess={handleAuthSuccess} />
              </motion.div>
            ) : (
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="space-y-6"
              >
                {/* Home Code Generator */}
                {activeTab === 'home' && (
                  <HomeSolver
                    onCameraClick={handleCameraTrigger}
                    solvesRemaining={solvesRemaining}
                    useSolveCredit={useSolveCredit}
                    isPremium={isPremium}
                    onGoToPremium={() => setActiveTab('profile')}
                    onWatchInstantAd={handleInstantAdCredit}
                    isWatchingAd={isWatchingHeaderAd}
                  />
                )}

                {/* Code Converter */}
                {activeTab === 'convert' && (
                  <Converter
                    onCameraClick={handleCameraTrigger}
                    solvesRemaining={solvesRemaining}
                    useSolveCredit={useSolveCredit}
                    isPremium={isPremium}
                    onGoToPremium={() => setActiveTab('profile')}
                  />
                )}

                {/* Code Debugger */}
                {activeTab === 'debug' && (
                  <Debugger
                    onCameraClick={handleCameraTrigger}
                    isPremium={isPremium}
                    onGoToPremium={() => setActiveTab('profile')}
                  />
                )}

                {/* Programming Q&A / Tutor (Combined) */}
                {activeTab === 'ask' && (
                  <Tutor
                    onCameraClick={handleCameraTrigger}
                    isPremium={isPremium}
                  />
                )}

                {/* Textbook Assistant / Learn (Combined) */}
                {activeTab === 'book' && (
                  <Learn
                    onCameraClick={handleCameraTrigger}
                    isPremium={isPremium}
                  />
                )}

                {/* General Subject Tutor */}
                {activeTab === 'ai' && (
                  <Tutor
                    onCameraClick={handleCameraTrigger}
                    isPremium={isPremium}
                  />
                )}

                {/* Beginner Academy Path */}
                {activeTab === 'learn' && (
                  <Learn
                    onCameraClick={handleCameraTrigger}
                    isPremium={isPremium}
                  />
                )}

                {/* Full OCR tab scanner page redirected to Book Study / Learn Hub */}
                {activeTab === 'scan' && (
                  <Learn
                    onCameraClick={handleCameraTrigger}
                    isPremium={isPremium}
                  />
                )}

                {/* Student Profile Setting view */}
                {activeTab === 'profile' && (
                  <ProfileView
                    profile={profile}
                    setProfile={setProfile}
                    isPremium={isPremium}
                    onRedeemCode={handleRedeemCode}
                    solvesRemaining={solvesRemaining}
                    adProgress={adProgress}
                    onWatchAd={handleWatchAdReward}
                    onLogout={handleLogout}
                    onUpgradeToPremium={() => {
                      setIsPremium(true);
                      setIsAdFree(true);
                    }}
                    onResetCreditsAndScores={handleResetCreditsAndScores}
                  />
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* BOTTOM BANNER SPONSOR AD (Visible on free mode) */}
        {isLoggedIn && !isPremium && !isAdFree && (
          <div id="bottom-banner-sponsor" className="mx-4 mb-4 p-2 px-3 bg-gray-950 border border-gray-850 rounded-xl flex items-center justify-between text-[10px] text-gray-500 font-sans">
            <span>Sponsor: Unlock premium mode to completely strip ads.</span>
            <span className="text-[8px] bg-gray-900 border border-gray-800 text-gray-500 px-1 py-0.2 rounded font-mono font-sans">AD</span>
          </div>
        )}

        {/* STICKY BOTTOM NAVIGATION BAR */}
        {isLoggedIn && (
          <BottomNavBar
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isPremium={isPremium}
            isLoggedIn={isLoggedIn}
          />
        )}

        {/* UNIVERSAL CAMERA OCR MODAL STREAM DIALOG */}
        <CameraOCRModal
          isOpen={cameraModalOpen}
          onClose={() => setCameraModalOpen(false)}
          onExtractSuccess={(text) => {
            if (cameraTargetCallback) {
              cameraTargetCallback(text);
            }
          }}
          taskType={
            activeTab === 'convert'
              ? 'convert'
              : activeTab === 'debug'
              ? 'debug'
              : activeTab === 'ask'
              ? 'ask'
              : activeTab === 'book'
              ? 'scan'
              : 'solve'
          }
        />
      </div>
    </div>
  );
}
